package chosim.exampleforfun.taxna;



import androidx.annotation.Nullable;
import androidx.appcompat.app.AppCompatActivity;

import android.app.Activity;
import android.app.AlertDialog;
import android.app.ListActivity;
import android.content.ContentValues;
import android.content.Context;
import android.content.DialogInterface;
import android.content.Intent;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.view.Window;
import android.view.WindowManager;
import android.view.animation.Animation;
import android.view.animation.TranslateAnimation;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.LinearLayout;
import android.widget.ListView;
import android.widget.SimpleCursorAdapter;
import android.widget.TextView;
import android.widget.Toast;

class OpenHelper extends SQLiteOpenHelper {
    public OpenHelper(@Nullable Context context, @Nullable String name, @Nullable SQLiteDatabase.CursorFactory factory, int version) {
        super(context, name, factory, version);
    }

    @Override
    public void onCreate(SQLiteDatabase sqLiteDatabase) {
        String schema
                = "create table note(_id integer primary key autoincrement," +
                " title text not null , body text not null);";
        sqLiteDatabase.execSQL(schema);
    }

    @Override
    public void onUpgrade(SQLiteDatabase sqLiteDatabase, int i, int i1) {
    }
}

//메인화면에서 처리할 이벤트
//(1) 메모작성을 위한 "메모작성" 버튼 클릭 처리
//(2) 세부 메모내용을 보기위한 ListView 한줄 클릭 처리
//(3) ListView 한 줄을 롱클릭하여 메모 지우기 처리

public class MainActivity extends Activity {

    static final int READ = 0;
    static final int WRITE = 1;
    static final int ERROR = 2;

    ListView list;
    SQLiteDatabase sd;
    Cursor c;
    String _id = "";
    SimpleCursorAdapter adapter;
    View v;   //롱클릭에 따른 삭제처리시 애니메이션 대상이 되는 한 줄

    class MyDialogListener implements DialogInterface.OnClickListener {
        @Override
        public void onClick(DialogInterface dialogInterface, int i) {
            if (i == DialogInterface.BUTTON_POSITIVE) {
                //DB에서 롱클릭된 현재 메모 _id값을 사용하여 삭제
                String q = "delete from note where _id=" + _id + ";";
                sd.execSQL(q);  //DB에 쿼리문 실행요청

                //삭제 애니메이션 효과 적용
                TranslateAnimation tr
                        = new TranslateAnimation(0, 800, 0, 0);
                tr.setDuration(1000);

                tr.setAnimationListener(new Animation.AnimationListener() {
                    public void onAnimationStart(Animation animation) {
                        //삭제된 한줄 화면에 반영
                        //(1)DB에서 최신데이터 다시 읽어오기
                        c = sd.query("note", null, null,
                                null, null, null, null);
                    }
                    public void onAnimationEnd(Animation animation) {
                        //(2)리로딩해온 Cursor 값을 Adapter를 사용해 ListView에 반영
                        adapter.changeCursor(c);
                    }
                    public void onAnimationRepeat(Animation animation) {
                    }
                });
                v.startAnimation(tr);
            } else if (i == DialogInterface.BUTTON_NEGATIVE) {
                Toast.makeText(MainActivity.this,
                        "취소하셨습니다.",
                        Toast.LENGTH_SHORT).show();
            }
        }
    }

    @Override
    protected void onStart() {
        super.onStart();
        //UI 이외의 자원 할당
        //(2)ListView에 공급할 데이터 - DB에서 읽어온 데이터
        c = sd.query("note", null, null,
                null, null, null, null);

        //(3)ListView와 데이터를 연계해줄 Adapter 생성
        adapter = new SimpleCursorAdapter(this,
                R.layout.line,  //한줄의 모양
                c,//공급되는 데이터
                new String[]{"_id", "title"},//from
                new int[]{R.id.id, R.id.title}//to
        );
        //(4)ListView에 Adapter 적용
        list.setAdapter(adapter);
    }

    @Override
    protected void onStop() {
        super.onStop();
        //UI 이외의 자원 해제
        c.close();
    }

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        WindowManager wm = (WindowManager) this.getSystemService(Context.WINDOW_SERVICE);
        requestWindowFeature(Window.FEATURE_NO_TITLE);
        getWindow().setFlags(WindowManager.LayoutParams.FLAG_FULLSCREEN, WindowManager.LayoutParams.FLAG_FULLSCREEN);
        super.onCreate(savedInstanceState);


        OpenHelper oh = new OpenHelper(this, "test.db", null, 1);
        sd = oh.getWritableDatabase();

        //임의로 메모 데이터 작성해서 DB에 기록
        //ContentValues values = new ContentValues();
        //values.put("title", "첫번째 메모");
        //values.put("body", "불금");
        //sd.insert("note", null, values);


        setContentView(R.layout.mainactivity);
        //ListView
        //(1)ListView 생성
        list = findViewById(R.id.list);

        //되돌아 가기 버튼
        Button back=findViewById(R.id.back);
        back.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent j = new Intent(MainActivity.this,
                        Six_1.class);
                startActivity(j);
            }
        });

        //(1) 메모작성을 위한 "메모작성" 버튼 클릭 처리
        Button write = findViewById(R.id.write);
        write.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                //SubActivity로 화면 전환
                Intent i = new Intent(MainActivity.this,
                        SubActivity.class);
                i.putExtra("action", MainActivity.WRITE);
                startActivity(i);

                Log.d("##########", "메모작성 버튼 클릭");
            }
        });

        //(2) 세부 메모내용을 보기위한 ListView 한줄 클릭 처리
        list.setOnItemClickListener(new AdapterView.OnItemClickListener() {
            @Override
            public void onItemClick(AdapterView<?> adapterView, View view, int i, long l) {
                //선택된 ListView 한 줄의 _id값 가져오기
                LinearLayout layout = (LinearLayout)view;
                TextView t = (TextView)layout.getChildAt(0);
                String _id = t.getText().toString();

                //
                String title = "";
                String body = "";
                c.moveToFirst();
                while ( c.isAfterLast() == false) {
                    if ( _id.equals(c.getString(0)) ) { //listview 선택된 한줄과 _id가 같은가
                        title = c.getString(1);  //찾고자 하는 메모 title
                        body = c.getString(2);  //찾고자 하는 메모 body
                        break;
                    }
                    c.moveToNext();
                }

                //선택된 메모 세부내용을 보여주기 위해 SubActivity 호출
                Intent intent
                        = new Intent(MainActivity.this, SubActivity.class);
                intent.putExtra("action", MainActivity.READ);
                intent.putExtra("title", title);
                intent.putExtra("body", body);

                startActivity(intent);

                Log.d("##########", "ListView 한 줄 클릭");
            }
        });

        //(3) ListView 한 줄을 롱클릭하여 메모 지우기 처리
        list.setOnItemLongClickListener(new AdapterView.OnItemLongClickListener() {
            @Override
            public boolean onItemLongClick(AdapterView<?> adapterView, View view, int i, long l) {
                v = view; //롱클릭된 한줄 클래스 전체에 사용가능하도록 멤버변수에 저장
                // 콜백함수의 파라미터로 넘어온 View view 변수에는 리스트뷰에서 클릭된 한줄에 들어가 있음
                LinearLayout layout = (LinearLayout) view;
                //LinearLayout (한줄 루트)에 들어가 있는 0번째 UI 가져오기
                TextView temp = (TextView) layout.getChildAt(0);
                _id = temp.getText().toString(); //첫번째 UI가 가지고 있는 _id 값 가져오기

                MyDialogListener m = new MyDialogListener();
                //롱클릭에 따른 한줄 삭제 확인을 위해 팝업창 띄우기
                new AlertDialog.Builder(MainActivity.this)
                        .setMessage("정말 삭제 하시겠습니까?")
                        .setPositiveButton("YES", m)
                        .setNegativeButton("NO", m)
                        .show();


                Log.d("##########", _id + " 롱클릭!!");
                return true;   //true 인 경우 추가적으로 클릭 이벤트는 처리 안됨
            }
        });


    }
}
